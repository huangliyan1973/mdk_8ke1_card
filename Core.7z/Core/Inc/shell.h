#ifndef INC_SHELL_H_
#define INC_SHELL_H_

extern void eth_printf(const char *fmt, ...);
extern void sendstr(const char *str);
extern void shell_init(void);

#endif
