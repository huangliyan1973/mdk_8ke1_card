#ifndef _SDRAM_H
#define _SDRAM_H

#define SRAM_BASE_ADDR  (0x68000000)

#endif
