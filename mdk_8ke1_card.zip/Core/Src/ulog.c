/*
 * Copyright (c) 2006-2019, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2018-08-25     armink       the first version
 */

#include <string.h>
#include <stdarg.h>
#include <stdio.h>

#include "ulog.h"
#include "rt_service.h"
#include "lffifo.h"
#include "card_debug.h"

#define ULOG_ASYNC_OUTPUT_BUF_SIZE 2048
#define ULOG_LINE_BUF_SIZE 128

/* the number which is max stored line logs */
#ifndef ULOG_ASYNC_OUTPUT_STORE_LINES
#define ULOG_ASYNC_OUTPUT_STORE_LINES  (ULOG_ASYNC_OUTPUT_BUF_SIZE * 3 / 2 / ULOG_LINE_BUF_SIZE)
#endif

/**
 * CSI(Control Sequence Introducer/Initiator) sign
 * more information on https://en.wikipedia.org/wiki/ANSI_escape_code
 */
#define CSI_START                      "\033["
#define CSI_END                        "\033[0m"
/* output log front color */
#define F_BLACK                        "30m"
#define F_RED                          "31m"
#define F_GREEN                        "32m"
#define F_YELLOW                       "33m"
#define F_BLUE                         "34m"
#define F_MAGENTA                      "35m"
#define F_CYAN                         "36m"
#define F_WHITE                        "37m"

/* output log default color definition */
#ifndef ULOG_COLOR_DEBUG
#define ULOG_COLOR_DEBUG               NULL
#endif
#ifndef ULOG_COLOR_INFO
#define ULOG_COLOR_INFO                (F_GREEN)
#endif
#ifndef ULOG_COLOR_WARN
#define ULOG_COLOR_WARN                (F_YELLOW)
#endif
#ifndef ULOG_COLOR_ERROR
#define ULOG_COLOR_ERROR               (F_RED)
#endif
#ifndef ULOG_COLOR_ASSERT
#define ULOG_COLOR_ASSERT              (F_MAGENTA)
#endif

struct rt_ulog
{
    int init_ok;
    sys_mutex_t output_locker;
    /* all backends */
    rt_slist_t backend_list;
    /* the thread log's line buffer */
    char log_buf_th[ULOG_LINE_BUF_SIZE];

    //rt_rbb_t async_rbb;
    struct lffifo *async_fifo;
#if 0
    sys_thread_t async_th;
    sys_sem_t async_notice;
#endif

    struct
    {
        /* all tag's level filter */
        rt_slist_t tag_lvl_list;
        /* global filter level, tag and keyword */
        u32_t level;
        char tag[ULOG_FILTER_TAG_MAX_LEN + 1];
        char keyword[ULOG_FILTER_KW_MAX_LEN + 1];
    } filter;
};

/* ulog local object */
static struct rt_ulog ulog = { 0 };

/* level output info */
static const char * const level_output_info[] =
{
        "A/",
        NULL,
        NULL,
        "E/",
        "W/",
        NULL,
        "I/",
        "D/",
};

/* color output info */
static const char * const color_output_info[] =
{
        ULOG_COLOR_ASSERT,
        NULL,
        NULL,
        ULOG_COLOR_ERROR,
        ULOG_COLOR_WARN,
        NULL,
        ULOG_COLOR_INFO,
        ULOG_COLOR_DEBUG,
};

size_t ulog_strcpy(size_t cur_len, char *dst, const char *src)
{
    const char *src_old = src;

    CARD_ASSERT("dst != NULL", dst);
    CARD_ASSERT("src != NULL", src);

    while (*src != 0)
    {
        /* make sure destination has enough space */
        if (cur_len++ < ULOG_LINE_BUF_SIZE)
        {
            *dst++ = *src++;
        }
        else
        {
            break;
        }
    }
    return src - src_old;
}

size_t ulog_ultoa(char *s, unsigned long int n)
{
    size_t i = 0, j = 0, len = 0;
    char swap;

    do
    {
        s[len++] = n % 10 + '0';
    } while (n /= 10);
    s[len] = '\0';
    /* reverse string */
    for (i = 0, j = len - 1; i < j; ++i, --j)
    {
        swap = s[i];
        s[i] = s[j];
        s[j] = swap;
    }
    return len;
}

static void output_unlock(void)
{
    sys_mutex_unlock(&ulog.output_locker);
}

static void output_lock(void)
{
    sys_mutex_lock(&ulog.output_locker);
}

static char *get_log_buf(void)
{
    return ulog.log_buf_th;
}

__WEAK size_t ulog_formater(char *log_buf, u32_t level, const char *tag, int newline,
        const char *format, va_list args)
{
    /* the caller has locker, so it can use static variable for reduce stack usage */
    static size_t log_len, newline_len;
    static int fmt_result;

    CARD_ASSERT("log_buf != NULL", log_buf);
    CARD_ASSERT("level <= LOG_LVL_DBG", level <= LOG_LVL_DBG);
    CARD_ASSERT("tag != NULL", tag);
    CARD_ASSERT("format != NULL", format);

    log_len = 0;
    newline_len = strlen(ULOG_NEWLINE_SIGN);

    /* add CSI start sign and color info */
    if (color_output_info[level])
    {
        log_len += ulog_strcpy(log_len, log_buf + log_len, CSI_START);
        log_len += ulog_strcpy(log_len, log_buf + log_len, color_output_info[level]);
    }

    /* time stamp */
    static size_t tick_len = 0;
    log_buf[log_len] = '[';
    tick_len = ulog_ultoa(log_buf + log_len + 1, HAL_GetTick());
    log_buf[log_len + 1 + tick_len] = ']';
    log_buf[log_len + 1 + tick_len +1] = '\0';
    log_len += strlen(log_buf + log_len);

    /* tag */
    log_len += ulog_strcpy(log_len, log_buf + log_len, " ");
    log_len += ulog_strcpy(log_len, log_buf + log_len, tag);

    log_len += ulog_strcpy(log_len, log_buf + log_len, ": ");

    fmt_result = vsnprintf(log_buf + log_len, ULOG_LINE_BUF_SIZE - log_len, format, args);

    /* calculate log length */
    if ((log_len + fmt_result <= ULOG_LINE_BUF_SIZE) && (fmt_result > -1))
    {
        log_len += fmt_result;
    }
    else
    {
        /* using max length */
        log_len = ULOG_LINE_BUF_SIZE;
    }

    /* overflow check and reserve some space for CSI end sign and newline sign */

    if (log_len + (sizeof(CSI_END) - 1) + newline_len > ULOG_LINE_BUF_SIZE)
    {
        /* using max length */
        log_len = ULOG_LINE_BUF_SIZE;
        /* reserve some space for CSI end sign */
        log_len -= (sizeof(CSI_END) - 1);
        /* reserve some space for newline sign */
        log_len -= newline_len;
    }

    /* package newline sign */
    if (newline)
    {
        log_len += ulog_strcpy(log_len, log_buf + log_len, ULOG_NEWLINE_SIGN);
    }

    /* add CSI end sign  */
    if (color_output_info[level])
    {
        log_len += ulog_strcpy(log_len, log_buf + log_len, CSI_END);
    }

    return log_len;
}

#if 0
void ulog_output_to_all_backend(u32_t level, const char *tag, int is_raw, const char *log, size_t size)
{
    rt_slist_t *node;
    ulog_backend_t backend;

    if (!ulog.init_ok)
        return;

    /* output for all backends */
    for (node = rt_slist_first(&ulog.backend_list); node; node = rt_slist_next(node))
    {
        backend = rt_slist_entry(node, struct ulog_backend, list);
        if (backend->support_color)
        {
            backend->output(backend, level, tag, is_raw, log, size);
        }
        else
        {
            /* recalculate the log start address and log size when backend not supported color */
            size_t color_info_len = strlen(color_output_info[level]), output_size = size;
            if (color_info_len)
            {
                size_t color_hdr_len = strlen(CSI_START) + color_info_len;

                log += color_hdr_len;
                output_size -= (color_hdr_len + (sizeof(CSI_END) - 1));
            }
            backend->output(backend, level, tag, is_raw, log, output_size);
        }
    }
}

static void do_output(rt_uint32_t level, const char *tag, rt_bool_t is_raw, const char *log_buf, rt_size_t log_len)
{
    rt_rbb_blk_t log_blk;
    ulog_frame_t log_frame;

    lffifo_put()
    /* allocate log frame */
    log_blk = rt_rbb_blk_alloc(ulog.async_rbb, RT_ALIGN(sizeof(struct ulog_frame) + log_len, RT_ALIGN_SIZE));
    if (log_blk)
    {
        /* package the log frame */
        log_frame = (ulog_frame_t) log_blk->buf;
        log_frame->magic = ULOG_FRAME_MAGIC;
        log_frame->is_raw = is_raw;
        log_frame->level = level;
        log_frame->log_len = log_len;
        log_frame->tag = tag;
        log_frame->log = (const char *)log_blk->buf + sizeof(struct ulog_frame);
        /* copy log data */
        rt_memcpy(log_blk->buf + sizeof(struct ulog_frame), log_buf, log_len);
        /* put the block */
        rt_rbb_blk_put(log_blk);
        /* send a notice */
        rt_sem_release(&ulog.async_notice);
    }
    else
    {
        static rt_bool_t already_output = RT_FALSE;
        if (already_output == RT_FALSE)
        {
            rt_kprintf("Warning: There is no enough buffer for saving async log,"
                    " please increase the ULOG_ASYNC_OUTPUT_BUF_SIZE option.\n");
            already_output = RT_TRUE;
        }
    }
}
#endif


/**
 * output the log by variable argument list
 *
 * @param level level
 * @param tag tag
 * @param newline has_newline
 * @param format output format
 * @param args variable argument list
 */
void ulog_voutput(u32_t level, const char *tag, int newline, const char *format, va_list args)
{
    char *log_buf = NULL;
    size_t log_len = 0;

    CARD_ASSERT("level <= LOG_LVL_DBG", level <= LOG_LVL_DBG);
    CARD_ASSERT("tag != NULL", tag);
    CARD_ASSERT("format != NULL", format);

    if (!ulog.init_ok)
    {
        return;
    }

    /* level filter */
    if (level > ulog.filter.level || level > ulog_tag_lvl_filter_get(tag))
    {
        return;
    }
    else if (!strstr(tag, ulog.filter.tag))
    {
        /* tag filter */
        return;
    }

    /* get log buffer */
    log_buf = get_log_buf();

    /* lock output */
    output_lock();

    log_len = ulog_formater(log_buf, level, tag, newline, format, args);
    /* keyword filter */
    if (ulog.filter.keyword[0] != '\0')
    {
        /* add string end sign */
        log_buf[log_len] = '\0';
        /* find the keyword */
        if (!strstr(log_buf, ulog.filter.keyword))
        {
            /* unlock output */
            output_unlock();
            return;
        }
    }
    /* do log output */
    lffifo_put(ulog.async_fifo, (u8_t *)log_buf, log_len);

    /* unlock output */
    output_unlock();
}

static void do_output(u32_t level, const char *tag, int is_raw, const char *log_buf, size_t log_len)
{
    (void)is_raw;
    
    CARD_ASSERT("level <= LOG_LVL_DBG", level <= LOG_LVL_DBG);
    CARD_ASSERT("tag != NULL", tag);

    if (!ulog.init_ok)
    {
        return;
    }

    /* level filter */
    if (level > ulog.filter.level || level > ulog_tag_lvl_filter_get(tag))
    {
        return;
    }
    else if (!strstr(tag, ulog.filter.tag))
    {
        /* tag filter */
        return;
    }

    /* get log buffer */
    log_buf = get_log_buf();

    /* lock output */
    output_lock();

#if 0
    if (ulog.filter.keyword[0] != '\0')
    {
        /* add string end sign */
        log_buf[log_len] = '\0';
        /* find the keyword */
        if (!strstr(log_buf, ulog.filter.keyword))
        {
            /* unlock output */
            output_unlock();
            return;
        }
    }
#endif
    /* do log output */
    lffifo_put(ulog.async_fifo, (u8_t *)log_buf, log_len);

    /* unlock output */
    output_unlock();
}

/**
 * output the log
 *
 * @param level level
 * @param tag tag
 * @param newline has newline
 * @param format output format
 * @param ... args
 */
void ulog_output(u32_t level, const char *tag, int newline, const char *format, ...)
{
    va_list args;

    /* args point to the first variable parameter */
    va_start(args, format);

    ulog_voutput(level, tag, newline, format, args);

    va_end(args);
}

/**
 * output RAW string format log
 *
 * @param format output format
 * @param ... args
 */
void ulog_raw(const char *format, ...)
{
    size_t log_len = 0;
    char *log_buf = NULL;
    va_list args;
    int fmt_result;

    CARD_ASSERT("ulog.init_ok != 0", ulog.init_ok);

    /* get log buffer */
    log_buf = get_log_buf();

    /* lock output */
    output_lock();
    /* args point to the first variable parameter */
    va_start(args, format);

    fmt_result = vsnprintf(log_buf, ULOG_LINE_BUF_SIZE, format, args);

    va_end(args);

    /* calculate log length */
    if ((fmt_result > -1) && (fmt_result <= ULOG_LINE_BUF_SIZE))
    {
        log_len = fmt_result;
    }
    else
    {
        log_len = ULOG_LINE_BUF_SIZE;
    }

    /* do log output */
    do_output(LOG_LVL_DBG, NULL, 1, log_buf, log_len);

    /* unlock output */
    output_unlock();
}

/**
 * dump the hex format data to log
 *
 * @param tag name for hex object, it will show on log header
 * @param width hex number for every line, such as: 16, 32
 * @param buf hex buffer
 * @param size buffer size
 */
void ulog_hexdump(const char *tag, size_t width, u8_t *buf, size_t size)
{
#define __is_print(ch)       ((unsigned int)((ch) - ' ') < 127u - ' ')

    size_t i, j;
    size_t log_len = 0, name_len = strlen(tag);
    char *log_buf = NULL, dump_string[8];
    int fmt_result;

    CARD_ASSERT("ulog.init_ok != 0", ulog.init_ok);

    /* level filter */
    if (LOG_LVL_DBG > ulog.filter.level || LOG_LVL_DBG > ulog_tag_lvl_filter_get(tag))
    {
        return;
    }
    else if (!strstr(tag, ulog.filter.tag))
    {
        /* tag filter */
        return;
    }

    /* get log buffer */
    log_buf = get_log_buf();

    /* lock output */
    output_lock();

    for (i = 0, log_len = 0; i < size; i += width)
    {
        /* package header */
        if (i == 0)
        {
            log_len += ulog_strcpy(log_len, log_buf + log_len, "D/HEX ");
            log_len += ulog_strcpy(log_len, log_buf + log_len, tag);
            log_len += ulog_strcpy(log_len, log_buf + log_len, ": ");
        }
        else
        {
            log_len = 6 + name_len + 2;
            memset(log_buf, ' ', log_len);
        }
        fmt_result = snprintf(log_buf + log_len, ULOG_LINE_BUF_SIZE, "%04X-%04X: ", i, i + width - 1);
        /* calculate log length */
        if ((fmt_result > -1) && (fmt_result <= ULOG_LINE_BUF_SIZE))
        {
            log_len += fmt_result;
        }
        else
        {
            log_len = ULOG_LINE_BUF_SIZE;
        }
        /* dump hex */
        for (j = 0; j < width; j++)
        {
            if (i + j < size)
            {
                snprintf(dump_string, sizeof(dump_string), "%02X ", buf[i + j]);
            }
            else
            {
                strncpy(dump_string, "   ", sizeof(dump_string));
            }
            log_len += ulog_strcpy(log_len, log_buf + log_len, dump_string);
            if ((j + 1) % 8 == 0)
            {
                log_len += ulog_strcpy(log_len, log_buf + log_len, " ");
            }
        }
        log_len += ulog_strcpy(log_len, log_buf + log_len, "  ");
        /* dump char for hex */
        for (j = 0; j < width; j++)
        {
            if (i + j < size)
            {
                snprintf(dump_string, sizeof(dump_string), "%c", __is_print(buf[i + j]) ? buf[i + j] : '.');
                log_len += ulog_strcpy(log_len, log_buf + log_len, dump_string);
            }
        }
        /* overflow check and reserve some space for newline sign */
        if (log_len + strlen(ULOG_NEWLINE_SIGN) > ULOG_LINE_BUF_SIZE)
        {
            log_len = ULOG_LINE_BUF_SIZE - strlen(ULOG_NEWLINE_SIGN);
        }
        /* package newline sign */
        log_len += ulog_strcpy(log_len, log_buf + log_len, ULOG_NEWLINE_SIGN);
        /* do log output */
        do_output(LOG_LVL_DBG, NULL, 1, log_buf, log_len);
    }
    /* unlock output */
    output_unlock();
}

#if 0

/**
 * Set the filter's level by different tag.
 * The log on this tag which level is less than it will stop output.
 *
 * example:
 *     // the example tag log enter silent mode
 *     ulog_set_filter_lvl("example", LOG_FILTER_LVL_SILENT);
 *     // the example tag log which level is less than INFO level will stop output
 *     ulog_set_filter_lvl("example", LOG_LVL_INFO);
 *     // remove example tag's level filter, all level log will resume output
 *     ulog_set_filter_lvl("example", LOG_FILTER_LVL_ALL);
 *
 * @param tag log tag
 * @param level The filter level. When the level is LOG_FILTER_LVL_SILENT, the log enter silent mode.
 *        When the level is LOG_FILTER_LVL_ALL, it will remove this tag's level filer.
 *        Then all level log will resume output.
 *
 * @return  0 : success
 *         -5 : no memory
 *         -10: level is out of range
 */
int ulog_tag_lvl_filter_set(const char *tag, u32_t level)
{
    rt_slist_t *node;
    ulog_tag_lvl_filter_t tag_lvl = NULL;
    int result = 0;

    if (level > LOG_FILTER_LVL_ALL)
        return -10;

    if (!ulog.init_ok)
        return result;

    /* lock output */
    output_lock();
    /* find the tag in list */
    for (node = rt_slist_first(ulog_tag_lvl_list_get()); node; node = rt_slist_next(node))
    {
        tag_lvl = rt_slist_entry(node, struct ulog_tag_lvl_filter, list);
        if (!strncmp(tag_lvl->tag, tag, ULOG_FILTER_TAG_MAX_LEN))
        {
            break;
        }
        else
        {
            tag_lvl = NULL;
        }
    }
    /* find OK */
    if (tag_lvl)
    {
        if (level == LOG_FILTER_LVL_ALL)
        {
            /* remove current tag's level filter when input level is the lowest level */
            rt_slist_remove(ulog_tag_lvl_list_get(), &tag_lvl->list);
            vPortFree(tag_lvl);
        }
        else
        {
            /* update level */
            tag_lvl->level = level;
        }
    }
    else
    {
        /* only add the new tag's level filer when level is not LOG_FILTER_LVL_ALL */
        if (level != LOG_FILTER_LVL_ALL)
        {
            /* new a tag's level filter */
            tag_lvl = (ulog_tag_lvl_filter_t)pvPortMalloc(sizeof(struct ulog_tag_lvl_filter));
            if (tag_lvl)
            {
                memset(tag_lvl->tag, 0 , sizeof(tag_lvl->tag));
                strncpy(tag_lvl->tag, tag, ULOG_FILTER_TAG_MAX_LEN);
                tag_lvl->level = level;
                rt_slist_append(ulog_tag_lvl_list_get(), &tag_lvl->list);
            }
            else
            {
                result = -5;
            }
        }
    }
    /* unlock output */
    output_unlock();

    return result;
}

/**
 * get the level on tag's level filer
 *
 * @param tag log tag
 *
 * @return It will return the lowest level when tag was not found.
 *         Other level will return when tag was found.
 */
u32_t ulog_tag_lvl_filter_get(const char *tag)
{
    rt_slist_t *node;
    ulog_tag_lvl_filter_t tag_lvl = NULL;
    u32_t level = LOG_FILTER_LVL_ALL;

    if (!ulog.init_ok)
        return level;

    /* lock output */
    output_lock();
    /* find the tag in list */
    for (node = rt_slist_first(ulog_tag_lvl_list_get()); node; node = rt_slist_next(node))
    {
        tag_lvl = rt_slist_entry(node, struct ulog_tag_lvl_filter, list);
        if (!strncmp(tag_lvl->tag, tag, ULOG_FILTER_TAG_MAX_LEN))
        {
            level = tag_lvl->level;
            break;
        }
    }
    /* unlock output */
    output_unlock();

    return level;
}

/**
 * get the tag's level list on filter
 *
 * @return tag's level list
 */
rt_slist_t *ulog_tag_lvl_list_get(void)
{
    return &ulog.filter.tag_lvl_list;
}

/**
 * set log global filter level
 *
 * @param level log level: LOG_LVL_ASSERT, LOG_LVL_ERROR, LOG_LVL_WARNING, LOG_LVL_INFO, LOG_LVL_DBG
 *              LOG_FILTER_LVL_SILENT: disable all log output, except assert level
 *              LOG_FILTER_LVL_ALL: enable all log output
 */
void ulog_global_filter_lvl_set(u32_t level)
{
    CARD_ASSERT("level <= LOG_FILTER_LVL_ALL", level <= LOG_FILTER_LVL_ALL);

    ulog.filter.level = level;
}

/**
 * get log global filter level
 *
 * @return log level: LOG_LVL_ASSERT, LOG_LVL_ERROR, LOG_LVL_WARNING, LOG_LVL_INFO, LOG_LVL_DBG
 *              LOG_FILTER_LVL_SILENT: disable all log output, except assert level
 *              LOG_FILTER_LVL_ALL: enable all log output
 */
u32_t ulog_global_filter_lvl_get(void)
{
    return ulog.filter.level;
}

/**
 * set log global filter tag
 *
 * @param tag tag
 */
void ulog_global_filter_tag_set(const char *tag)
{
    CARD_ASSERT("tag != NULL", tag);

    strncpy(ulog.filter.tag, tag, ULOG_FILTER_TAG_MAX_LEN);
}

/**
 * get log global filter tag
 *
 * @return tag
 */
const char *ulog_global_filter_tag_get(void)
{
    return ulog.filter.tag;
}

/**
 * set log global filter keyword
 *
 * @param keyword keyword
 */
void ulog_global_filter_kw_set(const char *keyword)
{
    CARD_ASSERT("keyword != NULL", keyword);

    strncpy(ulog.filter.keyword, keyword, ULOG_FILTER_KW_MAX_LEN);
}

/**
 * get log global filter keyword
 *
 * @return keyword
 */
const char *ulog_global_filter_kw_get(void)
{
    return ulog.filter.keyword;
}

int ulog_backend_register(ulog_backend_t backend, const char *name, int support_color)
{
    u32_t level;

    CARD_ASSERT("backend != NULL", backend);
    CARD_ASSERT("name != NULL", name);
    CARD_ASSERT("ulog.init_ok != 0", ulog.init_ok);
    CARD_ASSERT("backend->output != NULL", backend->output);

    if (backend->init)
    {
        backend->init(backend);
    }

    backend->support_color = support_color;
    memcpy(backend->name, name, BACKLEND_NAME_MAX);

    //level = rt_hw_interrupt_disable();
    rt_slist_append(&ulog.backend_list, &backend->list);
    //rt_hw_interrupt_enable(level);

    return 0;
}

int ulog_backend_unregister(ulog_backend_t backend)
{
    rt_base_t level;

    CARD_ASSERT("backend != NULL", backend);
    CARD_ASSERT("ulog.init_ok != 0", ulog.init_ok);

    if (backend->deinit)
    {
        backend->deinit(backend);
    }

    //level = rt_hw_interrupt_disable();
    rt_slist_remove(&ulog.backend_list, &backend->list);
    //rt_hw_interrupt_enable(level);

    return 0;
}

/**
 * asynchronous output logs to all backends
 *
 * @note you must call this function when ULOG_ASYNC_OUTPUT_BY_THREAD is disable
 */
void ulog_async_output(void)
{
    rt_rbb_blk_t log_blk;
    ulog_frame_t log_frame;

    while ((log_blk = rt_rbb_blk_get(ulog.async_rbb)) != NULL)
    {
        log_frame = (ulog_frame_t) log_blk->buf;
        if (log_frame->magic == ULOG_FRAME_MAGIC)
        {
            /* output to all backends */
            ulog_output_to_all_backend(log_frame->level, log_frame->tag, log_frame->is_raw, log_frame->log,
                    log_frame->log_len);
        }
        rt_rbb_blk_free(ulog.async_rbb, log_blk);
    }
}

/**
 * waiting for get asynchronous output log
 *
 * @param time the waiting time
 */
void ulog_async_waiting_log(u32_t time)
{
    sys_arch_sem_wait(&ulog.async_notice, time);
}

static void async_output_thread_entry(void *param)
{
    ulog_async_output();

    while (1)
    {
        ulog_async_waiting_log(osWaitForever);
        ulog_async_output();
    }
}

/**
 * flush all backends's log
 */
void ulog_flush(void)
{
    rt_slist_t *node;
    ulog_backend_t backend;

    if (!ulog.init_ok)
        return;

    ulog_async_output();

    /* flush all backends */
    for (node = rt_slist_first(&ulog.backend_list); node; node = rt_slist_next(node))
    {
        backend = rt_slist_entry(node, struct ulog_backend, list);
        if (backend->flush)
        {
            backend->flush(backend);
        }
    }
}

#endif

struct lffifo  *ulog_get_buf(void)
{
    return ulog.async_fifo;
}

int ulog_init(void)
{
    if (ulog.init_ok)
        return 0;

    if (sys_mutex_new(&ulog.output_locker) != ERR_OK) {
        CARD_ASSERT("failed to create ulog.output_locker", 0);
    }
    
    rt_slist_init(&ulog.backend_list);

    ulog.async_fifo = lffifo_alloc(ULOG_ASYNC_OUTPUT_BUF_SIZE);
    CARD_ASSERT("ulog.async_fifo != NULL", ulog.async_fifo);

#if 0
    rt_slist_init(ulog_tag_lvl_list_get());

    /* async output ring block buffer */
    ulog.async_rbb = rt_rbb_create(RT_ALIGN(ULOG_ASYNC_OUTPUT_BUF_SIZE, RT_ALIGN_SIZE), ULOG_ASYNC_OUTPUT_STORE_LINES);
    if (ulog.async_rbb == NULL)
    {
        rt_kprintf("Error: ulog init failed! No memory for async rbb.\n");
        rt_mutex_detach(&ulog.output_locker);
        return -RT_ENOMEM;
    }
    /* async output thread */
    ulog.async_th = rt_thread_create("ulog_async", async_output_thread_entry, &ulog, ULOG_ASYNC_OUTPUT_THREAD_STACK,
            ULOG_ASYNC_OUTPUT_THREAD_PRIORITY, 20);
    if (ulog.async_th == NULL)
    {
        rt_kprintf("Error: ulog init failed! No memory for async output thread.\n");
        rt_mutex_detach(&ulog.output_locker);
        rt_rbb_destroy(ulog.async_rbb);
        return -RT_ENOMEM;
    }

    /* async output thread startup */
    rt_thread_startup(ulog.async_th);

    ulog_global_filter_lvl_set(LOG_FILTER_LVL_ALL);
#endif

    ulog.init_ok = 1;

    return 0;
}


#if 0
void ulog_deinit(void)
{
    rt_slist_t *node;
    ulog_backend_t backend;

    if (!ulog.init_ok)
        return;

    /* deinit all backends */
    for (node = rt_slist_first(&ulog.backend_list); node; node = rt_slist_next(node))
    {
        backend = rt_slist_entry(node, struct ulog_backend, list);
        if (backend->deinit)
        {
            backend->deinit(backend);
        }
    }

    /* deinit tag's level filter */
    {
        ulog_tag_lvl_filter_t tag_lvl;
        for (node = rt_slist_first(ulog_tag_lvl_list_get()); node; node = rt_slist_next(node))
        {
            tag_lvl = rt_slist_entry(node, struct ulog_tag_lvl_filter, list);
            rt_free(tag_lvl);
        }
    }

    rt_mutex_detach(&ulog.output_locker);

    rt_rbb_destroy(ulog.async_rbb);
    rt_thread_delete(ulog.async_th);

    ulog.init_ok = 0;
}
#endif
