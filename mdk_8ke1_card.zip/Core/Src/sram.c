#include "main.h"
#include "card_debug.h"
#include "sram.h"

void sram_test(void)
{
    u32_t *sram = (u32_t *)SRAM_BASE_ADDR;

    for(u32_t i = 0; i < 0x20000; i++) {
        sram[i] = i;
    }

    for (u32_t i = 0; i < 0x20000; i++) {
        if (sram[i] != i) {
            CARD_DEBUGF(1, ("SRAM TEST FAILED!\n"));
        }
    }

    CARD_DEBUGF(1, ("SRAM TEST OK!\n"));
}
