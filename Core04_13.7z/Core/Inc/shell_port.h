#ifndef INC_SHELL_PORT_H_
#define INC_SHELL_PORT_H_

#include "shell.h"

extern Shell shell;

void userShellInit(void);

void shell_init(void);

#endif
